// Simple state & demo data
const screens = document.querySelectorAll('.screen');
document.querySelectorAll('.nav-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    screens.forEach(s=>s.classList.remove('active'));
    document.getElementById(btn.dataset.screen).classList.add('active');
  });
});

// CUSTOMER BOOKING
document.getElementById('bookBtn').addEventListener('click', ()=>{
  const svc = document.getElementById('svc').value;
  const win = document.getElementById('window').value;
  const name = document.getElementById('custName').value || 'Customer';
  const phone = document.getElementById('custPhone').value || '—';
  const addr = document.getElementById('custAddr').value || '—';
  const deposit = document.getElementById('deposit').value; // $29 default
  // In live app: POST /checkout/deposit to create Square Checkout Link for $29 and attach to Job.
  window.demoJobs.unshift({
    id: 'JOB'+Math.floor(Math.random()*10000),
    service: svc,
    window: win,
    customer: name,
    phone, addr,
    status: 'New',
    tech: null,
    deposit
  });
  document.getElementById('custConfirm').classList.remove('hidden');
  setTimeout(()=>document.getElementById('custConfirm').classList.add('hidden'), 2200);
  renderBoard();
});

// TRACK TECH
let progress = 0;
const fill = document.getElementById('progFill');
const etaEl = document.getElementById('trackEta');
const statusEl = document.getElementById('trackStatus');

document.getElementById('simulateEnRoute').addEventListener('click', ()=>{
  progress = 50; fill.style.width = progress+'%';
  statusEl.textContent = 'En Route';
  etaEl.textContent = '35–45 min';
});
document.getElementById('simulateArrived').addEventListener('click', ()=>{
  progress = 100; fill.style.width = progress+'%';
  statusEl.textContent = 'Arrived';
  etaEl.textContent = '0–5 min';
});

// TECH APP
window.demoJobs = [
  {id:'JOB1234', service:'AC Repair', window:'8–10am', customer:'Mike R', phone:'801-555-0001', addr:'Murray, UT', status:'New', tech:null},
  {id:'JOB5678', service:'Tune-Up', window:'10–12pm', customer:'Laura P', phone:'801-555-0002', addr:'SLC, UT', status:'New', tech:null},
  {id:'JOB9012', service:'Install Quote', window:'12–2pm', customer:'Craig T', phone:'801-555-0003', addr:'Cottonwood Heights, UT', status:'New', tech:null},
];

const techJobsEl = document.getElementById('techJobs');
const techDetail = document.getElementById('techDetail');
const jobTitle = document.getElementById('jobTitle');
const jobMeta = document.getElementById('jobMeta');
const linesTbody = document.querySelector('#lines tbody');
const subtotalEl = document.getElementById('subtotal');
const taxEl = document.getElementById('tax');
const grandEl = document.getElementById('grand');

function renderTechJobs() {
  techJobsEl.innerHTML = '';
  window.demoJobs.forEach(j=>{
    const row = document.createElement('div');
    row.className = 'job';
    row.innerHTML = `
      <div>
        <strong>${j.service}</strong> • ${j.window}<br/>
        <small>${j.customer} • ${j.addr}</small>
      </div>
      <button data-id="${j.id}">Open</button>
    `;
    row.querySelector('button').addEventListener('click', ()=>openJob(j.id));
    techJobsEl.appendChild(row);
  });
}
renderTechJobs();

let currentJob = null;
let lineItems = [];

function openJob(id){
  currentJob = window.demoJobs.find(x=>x.id===id);
  jobTitle.textContent = `${currentJob.service} — ${currentJob.customer}`;
  jobMeta.textContent = `${currentJob.window} • ${currentJob.addr} • ${currentJob.phone}`;
  techDetail.style.display = 'block';
  lineItems = [];
  linesTbody.innerHTML = '';
  updateTotals();
}

function updateTotals(){
  const subtotal = lineItems.reduce((s,x)=>s+(x.qty*x.price),0);
  const tax = +(subtotal*0.0775).toFixed(2);
  const grand = +(subtotal+tax).toFixed(2);
  subtotalEl.textContent = subtotal.toFixed(2);
  taxEl.textContent = tax.toFixed(2);
  grandEl.textContent = grand.toFixed(2);
}

document.getElementById('addLine').addEventListener('click', ()=>{
  const desc = document.getElementById('liDesc').value || 'Part';
  const qty = +document.getElementById('liQty').value || 1;
  const price = +document.getElementById('liPrice').value || 0;
  lineItems.push({desc, qty, price});
  const tr = document.createElement('tr');
  tr.innerHTML = `<td>${desc}</td><td>${qty}</td><td>${price.toFixed(2)}</td><td>${(qty*price).toFixed(2)}</td>`;
  linesTbody.appendChild(tr);
  updateTotals();
});

function toast(id){ const t = document.getElementById(id); t.classList.remove('hidden'); setTimeout(()=>t.classList.add('hidden'), 1500); }
document.getElementById('sendEstimate').addEventListener('click', ()=>toast('techToast'));
document.getElementById('convertInvoice').addEventListener('click', ()=>toast('techToast'));
document.getElementById('takePayment').addEventListener('click', ()=>toast('techToast'));

// ADMIN BOARD (drag & drop)
const colUnassigned = document.getElementById('colUnassigned');
const colA = document.getElementById('colA');
const colB = document.getElementById('colB');

function renderBoard(){
  [colUnassigned,colA,colB].forEach(col=>col.innerHTML='');
  window.demoJobs.forEach(job=>{
    const li = document.createElement('li');
    li.textContent = `${job.id} • ${job.service} • ${job.window}`;
    li.draggable = true;
    li.dataset.id = job.id;
    (job.tech === 'A' ? colA : job.tech === 'B' ? colB : colUnassigned).appendChild(li);
  });
  addDnD(colUnassigned); addDnD(colA); addDnD(colB);
}
function addDnD(col){
  col.addEventListener('dragover', e=>e.preventDefault());
  col.addEventListener('drop', e=>{
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    const job = window.demoJobs.find(j=>j.id===id);
    if(col===colA) job.tech='A';
    else if(col===colB) job.tech='B';
    else job.tech=null;
    renderBoard();
  });
  col.querySelectorAll('li').forEach(li=>{
    li.addEventListener('dragstart', e=>{
      e.dataTransfer.setData('text/plain', li.dataset.id);
    });
  });
}
renderBoard();
