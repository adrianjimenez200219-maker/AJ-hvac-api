// Set this to your deployed server base URL, e.g. https://ajhvac-api.onrender.com
window.AJ_API_BASE = 'http://localhost:8787'; // change in production
